class DatosMensaje:
    def __init__(self):
        self.Nombre = ""
        self.Mensaje = ""