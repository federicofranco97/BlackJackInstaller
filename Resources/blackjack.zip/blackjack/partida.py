
class Partida:

    def __init__(self):
        self.idPartida = 0
        self.jugadores = {}
        self.mazo = []
        self.manoBanca = None